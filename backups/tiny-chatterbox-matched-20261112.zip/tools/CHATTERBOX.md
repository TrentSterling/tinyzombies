# Tiny Zombies: Chatterbox Turbo audition

The original 100 Kokoro OGG files are preserved byte-for-byte. The new bank is additive and selected by `?voice=chatterbox`; normal gameplay continues to use Kokoro.

Open `/voice-lab.html` to compare original processed audio, new processed audio and clean Chatterbox takes. Generation is offline on PC1, RTX 5070 Ti, using `chatterbox-tts 0.1.7`, Torch 2.8.0+cu128 and official ResembleAI/chatterbox-turbo revision `749d1c1a46eb10492095d68fbcf55691ccf137cd`. It uses the bundled default synthetic voice, not a celebrity or personal recording. Existing Kokoro voice IDs in the manifest are provenance, not claims of matching identities.

Turbo supports paralinguistic tags. This pass uses `[chuckle]` on selected celebratory barks and `[sigh]` on losses, keeping urgent instructions clear. Turbo ignores classic Chatterbox exaggeration/CFG, so those knobs are not advertised here. Kokoro pronunciation notation is removed before synthesis. The CSV's Kokoro speed values are preserved as source metadata, not applied as Turbo parameters.

`tiny_original_dsp.py` is the original Tiny handoff recipe, with only its import path made portable. `dsp.py` is the original trontbot4 DSP source. Radio50s/walkie filters, hiss, PA compressor/EQ/reverb and loudness finishing are reused, not reconstructed. See hashes in `chatterbox-dsp-provenance.json`.

Generate with the existing Chatterbox virtualenv:

    python tools/generate_chatterbox.py --model PATH_TO_OFFICIAL_TURBO_SNAPSHOT
    python tools/process_chatterbox.py

Set `NUMBA_CACHE_DIR` to a writable local directory and `PYTHONDONTWRITEBYTECODE=1` when the installed packages live outside your writable workspace. The processing script needs ffmpeg on PATH; both scripts resume existing outputs. Each generated take is atomically checkpointed. Keep official model weights outside git.

The pack targets mono 48 kHz Opus at approximately -16 LUFS, using the original iterative limiter. `validation.json` records measured loudness and file hashes. ASR spot checks are not human listening approval; isolated comic words may be poorly transcribed.

## Role-matched revision

The initial bundled-default-voice batch did not preserve the original speaker identities and is retained only as an archived draft. It is never the game default. Use `/voice-lab-matched.html` and `?voice=chatterbox-matched` for the corrected audition.

`build_voice_anchors.py` synthesizes clean references using the actual original three Kokoro voice IDs at their original rates: bm_george for radio, am_michael for PA announcements, and am_liam for walkie lines. Chatterbox conditions on each role's reference before rendering that role; it does not use the model's bundled default speaker. This is a synthetic-to-synthetic reference workflow. References and provenance are retained in `assets/audio/voice-anchors/`. Exact speaker likeness still needs human A/B evaluation; conditioning is not a guarantee of a perfect match.

`generate_chatterbox_matched.py` and `process_chatterbox_matched.py` build separate clean and DSP banks. The DSP code, parameters and original Kokoro bank are unchanged. The initial draft remains in its separate folders.
