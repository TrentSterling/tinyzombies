import os,json
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
from pathlib import Path
import soundfile as sf
from tiny_original_dsp import kokoro
P=Path(__file__).resolve().parents[1];out=P/'assets/audio/voice-anchors';out.mkdir(parents=True,exist_ok=True)
roles=[('bm_george',.92,'This is Radio Pleasant Acres. Good evening, neighbors. Keep your radios on and stay together. The shelter is open, the street is ours, and we are going to get everybody home.'),('am_michael',1.0,'Welcome to the neighborhood! Get ready for the biggest block party of your life. Bring your friends, watch the hedges, and give those zombies something to complain about!'),('am_liam',1.05,'Squad, check in. I have eyes on the neighbors. We are moving down the street together. Keep the route clear, watch each other, and get everybody safely to the shelter.')]
for voice,speed,text in roles:
 wav,sr=kokoro(text,voice,speed,'cpu');sf.write(out/(voice+'.wav'),wav,sr,subtype='PCM_16');print(voice,len(wav)/sr,flush=True)
(out/'provenance.json').write_text(json.dumps({'purpose':'Clean synthetic conditioning anchors, generated from the original Kokoro role voices; no third-party person recording.','roles':[{'voice':v,'speed':s,'text':t} for v,s,t in roles]},indent=2))
