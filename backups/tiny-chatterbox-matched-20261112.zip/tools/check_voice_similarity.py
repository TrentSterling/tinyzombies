import json,numpy as np,torch,librosa
from pathlib import Path
from safetensors.torch import load_file
from chatterbox.models.voice_encoder import VoiceEncoder
P=Path(__file__).resolve().parents[1];torch.set_num_threads(4)
ve=VoiceEncoder();ve.load_state_dict(load_file(r'C:\Users\trent\.cache\tiny-chatterbox\hub\models--ResembleAI--chatterbox-turbo\snapshots\749d1c1a46eb10492095d68fbcf55691ccf137cd\ve.safetensors'));ve.eval()
def embed(p):
 w,_=librosa.load(str(p),sr=16000);return ve.embeds_from_wavs([w],16000)[0]
def cos(a,b):return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)))
rows=json.loads((P/'assets/audio/chatterbox-matched-clean/manifest.json').read_text());results=[]
for role in ['bm_george','am_michael','am_liam']:
 r=max([r for r in rows if r['voice']==role],key=lambda r:r['seconds']);id=r['id'];ref=embed(P/'assets/audio/voice-anchors'/(role+'.wav'));new=embed(P/'assets/audio/chatterbox-matched-clean'/(id+'.wav'));old=embed(P/'assets/audio/chatterbox-clean'/(id+'.wav'));entry={'role':role,'line':id,'reference_similarity_matched':cos(ref,new),'reference_similarity_default_draft':cos(ref,old)};results.append(entry);print(entry,flush=True)
(P/'assets/audio/chatterbox-matched/speaker-similarity.json').write_text(json.dumps({'method':'Chatterbox VoiceEncoder cosine to clean synthetic source anchor; comparative metric, not human perceptual approval or gender classification.','results':results},indent=2))
