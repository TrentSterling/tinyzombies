import json,random,time,hashlib,shutil
from pathlib import Path
import numpy as np,torch,soundfile as sf
from chatterbox.tts_turbo import ChatterboxTurboTTS
P=Path(__file__).resolve().parents[1]; out=P/'assets/audio/chatterbox-clean';manifest=json.loads((out/'manifest.json').read_text())
model=ChatterboxTurboTTS.from_local(r'C:\Users\trent\.cache\tiny-chatterbox\hub\models--ResembleAI--chatterbox-turbo\snapshots\749d1c1a46eb10492095d68fbcf55691ccf137cd','cuda')
ids=['boing','linda_got_eaten','pool_guy_phil_got_eaten','trampoline_timmy_joined_the_squad','trampoline_timmy_is_safe']
archive=P/'local-first-takes';archive.mkdir(exist_ok=True)
for i,id in enumerate(ids):
 row=next(r for r in manifest if r['id']==id);seed=82200+i;random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
 prompt=row['text'];t=time.time();wav=model.generate(prompt,temperature=.65,repetition_penalty=1.2).squeeze().detach().cpu().numpy();path=out/(id+'.wav');shutil.copy2(path,archive/path.name);sf.write(path,wav,model.sr,subtype='PCM_16')
 row.update(prompt=prompt,tags=[],seed=seed,seconds=round(len(wav)/model.sr,3),peak=float(np.abs(wav).max()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),generation_seconds=round(time.time()-t,2),retake_reason='ASR ambiguity in initial take; human audition still recommended')
 processed=P/'assets/audio/chatterbox'/(id+'.ogg');shutil.move(str(processed),str(archive/processed.name))
 print(id,'retaken',flush=True)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
