"""CPU-only transcription spot check. Not a substitute for human listening."""
import json
from pathlib import Path
from faster_whisper import WhisperModel
P=Path(__file__).resolve().parents[1]
model=WhisperModel(r"C:\trontstack\chatterbox\hf\hub\models--Systran--faster-whisper-base\snapshots\ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66",device='cpu',compute_type='int8',cpu_threads=4)
rows=json.loads((P/'assets/audio/chatterbox-clean/manifest.json').read_text())
results=[]
for i in sorted(set([0,1,8,9,10,14,22,34,50,75,99]+[j for j,r in enumerate(rows) if any(n in r["id"] for n in ["marv_","linda_","kimberly_","timmy_"])])):
 if i>=len(rows):continue
 r=rows[i]; segs,_=model.transcribe(str(P/'assets/audio/chatterbox'/ (r['id']+'.ogg')),language='en',beam_size=3)
 actual=' '.join(s.text for s in segs);results.append(dict(id=r['id'],expected=r['text'],heard=actual));print(r['id'],actual,flush=True)
(P/'assets/audio/chatterbox/asr-spotcheck.json').write_text(json.dumps(results,indent=2))
