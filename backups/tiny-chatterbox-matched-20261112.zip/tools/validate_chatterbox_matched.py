import json,numpy as np,soundfile as sf,hashlib
from pathlib import Path
P=Path(__file__).resolve().parents[1];r=P/'assets/audio';rows=json.loads((r/'chatterbox-clean/manifest.json').read_text());report={'count':len(rows),'checks':[]}
assert len(rows)==100
for x in rows:
 for folder,ext in [('chatterbox-matched-clean','wav'),('chatterbox-matched','ogg')]:
  p=r/folder/(x['id']+'.'+ext);a,sr=sf.read(p);assert np.isfinite(a).all();assert len(a)>sr*.15;assert a.ndim==1
  report['checks'].append({'file':str(p.relative_to(P)).replace(chr(92),'/'),'sample_rate':sr,'seconds':round(len(a)/sr,3),'peak':round(float(np.abs(a).max()),5),'rms':round(float(np.sqrt(np.mean(a*a))),5),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report['original_pack_unchanged']=all(hashlib.sha256((r/'voice'/name).read_bytes()).hexdigest()==h for name,h in json.loads((r/'chatterbox-clean/original-pack-sha256.json').read_text()).items())
assert report['original_pack_unchanged']
(r/'chatterbox-matched/integrity.json').write_text(json.dumps(report,indent=2));print('200 valid mono audio files; original pack unchanged')
